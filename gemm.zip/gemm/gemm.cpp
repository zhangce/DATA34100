#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <chrono>
#include <vector>
#include <mach/mach_time.h>
#include <Accelerate/Accelerate.h>

// ---- Naive matmul: C = A * B, row-major, all NxN ----
void gemm_naive(const float* A, const float* B, float* C, int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            float sum = 0.0f;
            for (int k = 0; k < N; k++) {
                sum += A[i * N + k] * B[k * N + j];
            }
            C[i * N + j] = sum;
        }
    }
}

// ---- Blocked matmul: C = A * B, row-major, all NxN, block size T ----
template <int T>
void gemm_blocked(const float* A, const float* B, float* C, int N) {
    int B_count = N / T;
    for (int ib = 0; ib < B_count; ib++) {
        for (int jb = 0; jb < B_count; jb++) {
            for (int kb = 0; kb < B_count; kb++) {
                // C[ib][jb] += A[ib][kb] * B[kb][jb]  (each TxT)
                for (int i = 0; i < T; i++) {
                    for (int j = 0; j < T; j++) {
                        float sum = 0.0f;
                        for (int k = 0; k < T; k++) {
                            sum += A[(ib * T + i) * N + (kb * T + k)]
                                 * B[(kb * T + k) * N + (jb * T + j)];
                        }
                        C[(ib * T + i) * N + (jb * T + j)] += sum;
                    }
                }
            }
        }
    }
}

// ---- AMX blocked matmul ----
#include "amx.h"

template <int T>
void gemm_amx(const float* A, const float* B, float* C, int N) {
    static_assert(T == 32, "AMX kernel currently requires T=32");

    int B_count = N / T;

    AMX_SET();

    // Packed A for all kb blocks in a row: pack once, reuse across all jb
    float* A_packed_all = (float*)aligned_alloc(128, sizeof(float) * T * N);

    for (int ib = 0; ib < B_count; ib++) {

        // Pack all A blocks for this ib row
        ///////// ---
        for (int kb = 0; kb < B_count; kb++) {
            const float* A_block = &A[ib * T * N + kb * T];
            float* A_dst = &A_packed_all[kb * T * T];
            for (int k = 0; k < T; k++) {
                for (int i = 0; i < T; i++) {
                    A_dst[k * T + i] = A_block[i * N + k];
                }
            }
        }
        ///////// ---

        for (int jb = 0; jb < B_count; jb++) {
            for (int kb = 0; kb < B_count; kb++) {

                ///////// ---
                const float* A_kb = &A_packed_all[kb * T * T];
                for (int k = 0; k < T; k++) {
                    // Load B row into X: X[0] = B[k, 0:16], X[1] = B[k, 16:32]
                    const float* B_row = &B[(kb * T + k) * N + jb * T];
                    AMX_LDX(ldx_operand(B_row, 0));
                    AMX_LDX(ldx_operand(B_row + 16, 1));

                    // Load packed A column into Y: Y[0] = A[:,k][0:16], Y[1] = A[:,k][16:32]
                    const float* A_col = &A_kb[k * T];
                    AMX_LDY(ldy_operand(A_col, 0));
                    AMX_LDY(ldy_operand(A_col + 16, 1));

                    if (kb == 0 && k == 0) {
                        // First iteration: zero-init Z accumulators
                        AMX_FMA32(fma32_operand_skip_z(0,  0,  0));  // C[0:16,  0:16]
                        AMX_FMA32(fma32_operand_skip_z(1, 64,  0));  // C[0:16,  16:32]
                        AMX_FMA32(fma32_operand_skip_z(2,  0, 64));  // C[16:32, 0:16]
                        AMX_FMA32(fma32_operand_skip_z(3, 64, 64));  // C[16:32, 16:32]
                    } else {
                        // Accumulate
                        AMX_FMA32(fma32_operand(0,  0,  0));
                        AMX_FMA32(fma32_operand(1, 64,  0));
                        AMX_FMA32(fma32_operand(2,  0, 64));
                        AMX_FMA32(fma32_operand(3, 64, 64));
                    }
                }
                ///////// ---
            }

            // Store Z back to C (row-major)
            // Z row j*4+r holds 16 floats of C row:
            //   r=0: C[j, 0:16]    r=1: C[j, 16:32]
            //   r=2: C[16+j, 0:16] r=3: C[16+j, 16:32]
            ///////// ---
            for (int j = 0; j < 16; j++) {
                AMX_STZ(stz_operand(&C[(ib * T + j) * N + jb * T],      j * 4 + 0));
                AMX_STZ(stz_operand(&C[(ib * T + j) * N + jb * T + 16], j * 4 + 1));
                AMX_STZ(stz_operand(&C[(ib * T + 16 + j) * N + jb * T],      j * 4 + 2));
                AMX_STZ(stz_operand(&C[(ib * T + 16 + j) * N + jb * T + 16], j * 4 + 3));
            }
            ///////// ---
        }
    }

    AMX_CLR();
    free(A_packed_all);
}

// ---- Profiled AMX with trace output ----
struct TraceEvent {
    const char* name;
    uint64_t ts_start;
    uint64_t ts_end;
    double data_bytes;
    double flops;
    int ib, jb, kb;
};

static void write_trace(const char* filename, const std::vector<TraceEvent>& events) {
    mach_timebase_info_data_t info;
    mach_timebase_info(&info);

    uint64_t t0 = events[0].ts_start;
    for (auto& e : events) if (e.ts_start < t0) t0 = e.ts_start;

    FILE* f = fopen(filename, "w");
    fprintf(f, "[\n");
    for (size_t idx = 0; idx < events.size(); idx++) {
        auto& e = events[idx];
        double ts_us = (double)(e.ts_start - t0) * info.numer / info.denom / 1000.0;
        double dur_ns = (double)(e.ts_end - e.ts_start) * info.numer / info.denom;
        double dur_us = dur_ns / 1000.0;
        double dur_s = dur_ns / 1e9;
        double bw = dur_s > 0 ? e.data_bytes / dur_s / 1e9 : 0;
        double gf = dur_s > 0 ? e.flops / dur_s / 1e9 : 0;

        fprintf(f, "%s{\"name\":\"%s [%.1fKB, %.0fFLOP]\",\"cat\":\"%s\",\"ph\":\"X\","
                   "\"ts\":%.3f,\"dur\":%.3f,\"pid\":0,\"tid\":0,"
                   "\"args\":{\"data_KB\":%.1f,\"flops\":%.0f,"
                   "\"bw_GB_s\":%.2f,\"gflops\":%.2f,"
                   "\"ib\":%d,\"jb\":%d,\"kb\":%d}}\n",
                idx > 0 ? "," : "",
                e.name, e.data_bytes / 1024.0, e.flops, e.name,
                ts_us, dur_us, e.data_bytes / 1024.0, e.flops,
                bw, gf, e.ib, e.jb, e.kb);
    }
    fprintf(f, "]\n");
    fclose(f);
    printf("Wrote %s (%zu events)\n", filename, events.size());
}

template <int T>
void gemm_amx_profiled(const float* A, const float* B, float* C, int N) {
    static_assert(T == 32, "AMX kernel currently requires T=32");

    int B_count = N / T;
    // Pre-calculate data sizes
    double pack_bytes = 2.0 * T * N * sizeof(float);  // read A + write A_packed
    double compute_load_bytes = T * 4.0 * 64;         // T iters * (2 LDX + 2 LDY) * 64B
    double compute_flops = 2.0 * T * T * T;           // 2 * T^3
    double store_bytes = T * T * sizeof(float);        // write 32x32 floats

    std::vector<TraceEvent> events;
    events.reserve(B_count + B_count * B_count * B_count + B_count * B_count);

    AMX_SET();

    float* A_packed_all = (float*)aligned_alloc(128, sizeof(float) * T * N);

    for (int ib = 0; ib < B_count; ib++) {

        ///////// ---
        uint64_t t0 = mach_absolute_time();
        for (int kb = 0; kb < B_count; kb++) {
            const float* A_block = &A[ib * T * N + kb * T];
            float* A_dst = &A_packed_all[kb * T * T];
            for (int k = 0; k < T; k++) {
                for (int i = 0; i < T; i++) {
                    A_dst[k * T + i] = A_block[i * N + k];
                }
            }
        }
        uint64_t t1 = mach_absolute_time();
        events.push_back({"Pack_A", t0, t1, pack_bytes, 0, ib, -1, -1});
        ///////// ---

        for (int jb = 0; jb < B_count; jb++) {
            for (int kb = 0; kb < B_count; kb++) {

                ///////// ---
                uint64_t tc0 = mach_absolute_time();
                const float* A_kb = &A_packed_all[kb * T * T];
                for (int k = 0; k < T; k++) {
                    const float* B_row = &B[(kb * T + k) * N + jb * T];
                    AMX_LDX(ldx_operand(B_row, 0));
                    AMX_LDX(ldx_operand(B_row + 16, 1));

                    const float* A_col = &A_kb[k * T];
                    AMX_LDY(ldy_operand(A_col, 0));
                    AMX_LDY(ldy_operand(A_col + 16, 1));

                    if (kb == 0 && k == 0) {
                        AMX_FMA32(fma32_operand_skip_z(0,  0,  0));
                        AMX_FMA32(fma32_operand_skip_z(1, 64,  0));
                        AMX_FMA32(fma32_operand_skip_z(2,  0, 64));
                        AMX_FMA32(fma32_operand_skip_z(3, 64, 64));
                    } else {
                        AMX_FMA32(fma32_operand(0,  0,  0));
                        AMX_FMA32(fma32_operand(1, 64,  0));
                        AMX_FMA32(fma32_operand(2,  0, 64));
                        AMX_FMA32(fma32_operand(3, 64, 64));
                    }
                }
                uint64_t tc1 = mach_absolute_time();
                events.push_back({"Compute", tc0, tc1, compute_load_bytes, compute_flops, ib, jb, kb});
                ///////// ---
            }

            ///////// ---
            uint64_t ts0 = mach_absolute_time();
            for (int j = 0; j < 16; j++) {
                AMX_STZ(stz_operand(&C[(ib * T + j) * N + jb * T],      j * 4 + 0));
                AMX_STZ(stz_operand(&C[(ib * T + j) * N + jb * T + 16], j * 4 + 1));
                AMX_STZ(stz_operand(&C[(ib * T + 16 + j) * N + jb * T],      j * 4 + 2));
                AMX_STZ(stz_operand(&C[(ib * T + 16 + j) * N + jb * T + 16], j * 4 + 3));
            }
            uint64_t ts1 = mach_absolute_time();
            events.push_back({"Store_Z", ts0, ts1, store_bytes, 0, ib, jb, -1});
            ///////// ---
        }
    }

    AMX_CLR();
    free(A_packed_all);

    write_trace("trace.json", events);
}

// ---- Accelerate reference ----
void gemm_accelerate(const float* A, const float* B, float* C, int N) {
    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                N, N, N,
                1.0f, A, N, B, N,
                0.0f, C, N);
}

// ---- Helpers ----
void fill_random(float* M, int N) {
    for (int i = 0; i < N * N; i++) {
        M[i] = (float)rand() / RAND_MAX * 2.0f - 1.0f;
    }
}

// Max absolute error and relative error
void check_correctness(const float* C_test, const float* C_ref, int N,
                       float& max_abs_err, float& max_rel_err) {
    max_abs_err = 0.0f;
    max_rel_err = 0.0f;
    for (int i = 0; i < N * N; i++) {
        float abs_err = fabsf(C_test[i] - C_ref[i]);
        float rel_err = abs_err / (fabsf(C_ref[i]) + 1e-9f);
        if (abs_err > max_abs_err) max_abs_err = abs_err;
        if (rel_err > max_rel_err) max_rel_err = rel_err;
    }
}

double gflops(int N, double seconds) {
    double ops = 2.0 * (double)N * (double)N * (double)N;
    return ops / seconds / 1e9;
}

// ---- Benchmark runner ----
typedef void (*gemm_fn)(const float*, const float*, float*, int);

struct BenchResult {
    double best_sec;
    double best_gflops;
    float max_abs_err;
    float max_rel_err;
};

BenchResult benchmark(const char* name, gemm_fn fn,
                      const float* A, const float* B, float* C,
                      const float* C_ref, int N, int warmup, int iters) {
    // Warmup
    for (int i = 0; i < warmup; i++) {
        fn(A, B, C, N);
    }

    double best = 1e30;
    for (int i = 0; i < iters; i++) {
        memset(C, 0, sizeof(float) * N * N);
        auto t0 = std::chrono::high_resolution_clock::now();
        fn(A, B, C, N);
        auto t1 = std::chrono::high_resolution_clock::now();
        double elapsed = std::chrono::duration<double>(t1 - t0).count();
        if (elapsed < best) best = elapsed;
    }

    float max_abs = 0, max_rel = 0;
    if (C_ref) {
        check_correctness(C, C_ref, N, max_abs, max_rel);
    }

    double gf = gflops(N, best);
    printf("%-20s | %8.3f ms | %8.2f GFLOPS | abs_err=%.2e  rel_err=%.2e\n",
           name, best * 1000.0, gf, max_abs, max_rel);

    return {best, gf, max_abs, max_rel};
}

int main() {
    const int N = 1024;
    printf("Matrix multiplication benchmark: %d x %d (float32)\n", N, N);
    printf("FLOPs per multiply: %.2f GFLOP\n\n", 2.0 * N / 1e9 * N * N);

    float* A     = (float*)aligned_alloc(64, sizeof(float) * N * N);
    float* B     = (float*)aligned_alloc(64, sizeof(float) * N * N);
    float* C     = (float*)aligned_alloc(64, sizeof(float) * N * N);
    float* C_ref = (float*)aligned_alloc(64, sizeof(float) * N * N);

    srand(42);
    fill_random(A, N);
    fill_random(B, N);

    // Compute reference with Accelerate
    printf("Computing Accelerate reference...\n");
    gemm_accelerate(A, B, C_ref, N);

    printf("\n%-20s | %8s    | %8s        | %s\n",
           "Kernel", "Time", "GFLOPS", "Error");
    printf("%.80s\n", "--------------------------------------------------------------------------------");

    // Benchmark Accelerate (3 warmup, 5 iters)
    benchmark("Accelerate", gemm_accelerate, A, B, C, C_ref, N, 3, 5);

    // Benchmark blocked T=32
    benchmark("Blocked (T=32)", gemm_blocked<32>, A, B, C, C_ref, N, 0, 3);

    // Benchmark AMX T=32
    benchmark("AMX (T=32)", gemm_amx<32>, A, B, C, C_ref, N, 1, 5);

    // Profiled AMX run → trace.json
    memset(C, 0, sizeof(float) * N * N);
    gemm_amx_profiled<32>(A, B, C, N);

    // Benchmark naive (0 warmup, 1 iter -- it's slow)
    benchmark("Naive", gemm_naive, A, B, C, C_ref, N, 0, 1);

    free(A); free(B); free(C); free(C_ref);
    return 0;
}
